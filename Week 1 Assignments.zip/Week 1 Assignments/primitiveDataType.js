let firstName = 'Shashank'
console.log(typeof(firstName))

let companyName = 'Alpha'
console.log(typeof(companyName))

let mobileNumber = 1234
console.log(typeof(mobileNumber))

let isAutomation = true
console.log(typeof(isAutomation))

let hasPlaywright
console.log(typeof(hasPlaywright))

